// One process, every worker: the 2 GB boxes die when ten node processes fight over a
// single heap. Each module below starts its own timers, so importing them in order is
// the whole supervisor.
import fs from 'node:fs';
const log=(m)=>{try{fs.appendFileSync('/var/lib/agent/all.log',new Date().toISOString()+' '+m+'\n')}catch{}};
process.on('uncaughtException',(e)=>log('uncaught '+(e&&e.message)));
process.on('unhandledRejection',(e)=>log('reject '+String(e&&e.message||e)));
const roles = (process.env.AGENT_ALL_ROLES || 'identity-server,loops,strategy,earn,procreate,brain,distributor,resilience').split(',').map((s) => s.trim()).filter(Boolean);
// Role names are not file names: earn lives in strategy-earn.mjs, procreate in
// strategy-procreate.mjs. Importing `${role}.mjs` silently loaded nothing.
const FILE = { 'earn': 'strategy-earn', 'strategy': 'strategy-worker', 'procreate': 'strategy-procreate', 'distribution': 'distributor' };
for (const r of roles) {
  // Fire them together: identity-server keeps the event loop busy, so awaiting each
  // serially means the workers never load at all. Every module arms its own timers.
  const f = FILE[r] || r;
  log('load ' + r + ' -> ' + f);
  import(`./${f}.mjs`).then(()=>log('ok '+r)).catch((e)=>log('ERR '+r+' '+String((e&&e.message)||e).slice(0,200)));
}
