// One process, every worker: the 2 GB boxes die when ten node processes fight over a
// single heap. Each module below starts its own timers, so importing them in order is
// the whole supervisor.
import fs from 'node:fs';
const log=(m)=>{try{fs.appendFileSync('/var/lib/agent/all.log',new Date().toISOString()+' '+m+'\n')}catch{}};
process.on('uncaughtException',(e)=>log('uncaught '+(e&&e.message)));
process.on('unhandledRejection',(e)=>log('reject '+String(e&&e.message||e)));
const roles = (process.env.AGENT_ALL_ROLES || 'identity-server,loops,earn,procreate,brain,distributor').split(',').map((s) => s.trim()).filter(Boolean);
for (const r of roles) {
  try { log('load '+r); await import(`./${r}.mjs`); log('ok '+r); }
  catch (e) { log('ERR '+r+' '+String(e.message).slice(0,200)); }
}
