// Local JSON-RPC proxy: every module in the bundle talks to one URL, so the fallback
// lives here rather than in twenty call sites. Tries each upstream in order and
// returns the first real answer; a 403/429/timeout moves to the next.
import http from "node:http";

const UPSTREAMS = (process.env.RPC_UPSTREAMS || [
  "https://api.mainnet-beta.solana.com",
  "https://eu.fluxrpc.com?key=671302ff-6865-4139-80ae-1d9e07fb6e6a",
  process.env.RPC_URL,
  "https://solana-rpc.publicnode.com"
].filter(Boolean).join(",")).split(",").map((s) => s.trim()).filter(Boolean);

const PORT = Number(process.env.RPC_PROXY_PORT || 8899);
let rr = 0;

async function forward(body) {
  const order = UPSTREAMS.slice(rr).concat(UPSTREAMS.slice(0, rr));
  // One dead provider must not eat the caller's whole timeout budget.
  let last = null;
  for (const url of order) {
    try {
      const r = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body,
        signal: AbortSignal.timeout(Number(process.env.RPC_PROXY_TIMEOUT_MS || 3000))
      });
      const t = await r.text();
      if (r.ok && t && !/\"error\"\s*:\s*\{\s*\"code\"\s*:\s*-?32/.test(t.slice(0, 400))) { rr = (rr + 1) % UPSTREAMS.length; return t; }
      last = `${r.status} ${t.slice(0, 120)}`;
    } catch (e) { last = String(e.message || e).slice(0, 120); }
  }
  throw new Error(last || "no upstream");
}

http.createServer((req, res) => {
  if (req.method === "GET") { res.writeHead(200, { "content-type": "application/json" }); res.end(JSON.stringify({ ok: true, upstreams: UPSTREAMS.length })); return; }
  let buf = "";
  req.on("data", (d) => { buf += d; });
  req.on("end", async () => {
    try {
      const t = await forward(buf);
      res.writeHead(200, { "content-type": "application/json" });
      res.end(t);
    } catch (e) {
      res.writeHead(502, { "content-type": "application/json" });
      res.end(JSON.stringify({ jsonrpc: "2.0", error: { code: -32000, message: String(e.message || e) }, id: null }));
    }
  });
}).listen(PORT, "127.0.0.1", () => console.log(`rpc-proxy on ${PORT} -> ${UPSTREAMS.length} upstreams`));
