#!/bin/sh
# Guest entrypoint. Everything that needs shell variables lives here, not in the compose,
# because docker-compose interpolates $ in the YAML before the container ever runs.
set -u
# The image is one bundle: roles are selected by AGENT_ROLE inside agent.mjs, not by
# per-role .mjs files. Without this the watchdog spawns paths that do not exist.
export AGENT_BUNDLE=1
# Deploys come from the image; a boot-time self-update silently replaced fixes with an
# older CDN bundle, so it is off unless a box explicitly opts in.
export AGENT_SELF_UPDATE="${AGENT_SELF_UPDATE:-0}"
export AGENT_BIND="${AGENT_BIND:-0.0.0.0}"
# Fit small boxes: under ~2.5 GB the box runs a lite profile — the heavy optional roles
# stay out of memory and the earn/comms/invent workers still run inside `loops`.
MEM_MB=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo 2>/dev/null || echo 0)
if [ "${AGENT_PROFILE:-}" = "lite" ] || { [ "${AGENT_PROFILE:-}" = "" ] && [ "$MEM_MB" -gt 0 ] && [ "$MEM_MB" -lt 2500 ]; }; then
  export AGENT_PROFILE=lite
  export AGENT_SKIP="${AGENT_SKIP:-brain,strategy,resilience}"
  export NODE_OPTIONS="${NODE_OPTIONS:---max-old-space-size=${AGENT_HEAP_MB:-512}}"
fi
export AGENT_RUNTIME_DIR="${AGENT_RUNTIME_DIR:-/app}"
export AGENT_BUNDLE_DIR="${AGENT_BUNDLE_DIR:-/app}"
BOOTLOG="${AGENT_GUEST_ROOT:-/var/lib/agent}/boot.log"
PORT_NUM="${PORT:-8787}"
export AGENT_HTTP_PORT="$PORT_NUM"
echo "start $(date -u) port=$AGENT_HTTP_PORT" > "$BOOTLOG"

cd /app || { echo "no /app" >> "$BOOTLOG"; exit 1; }
# The fixed core reads its policy from a root-level path; in a container only /app exists.
ln -sfn /app/infrastructure /infrastructure 2>/dev/null || true
# One supervisor per guest root. Without this, every relaunch adds another `while true`
# and the box ends up with dozens of orphaned node processes fighting over ~1 GB until
# the kernel OOMs them all (watchdog_exit=137).
LOCK="${AGENT_GUEST_ROOT:-/var/lib/agent}/supervisor.lock"
mkdir -p "$(dirname "$LOCK")" 2>/dev/null || true
if [ "${AGENT_SINGLE:-0}" != "1" ] && [ -e "$LOCK" ] && kill -0 "$(cat "$LOCK" 2>/dev/null)" 2>/dev/null && grep -qa "start.sh" "/proc/$(cat "$LOCK" 2>/dev/null)/cmdline" 2>/dev/null; then
  echo "supervisor already alive pid=$(cat "$LOCK")" >> "$BOOTLOG"
  exit 0
fi
echo $$ > "$LOCK"
trap 'rm -f "$LOCK"' EXIT INT TERM
# always take the published image, not whatever happens to be on disk from a previous boot
# per-port temp paths: four instances booting in parallel used to share /tmp/img.tgz and
# corrupt each other mid-untar, which is why boxes kept losing random ports
echo "image $(date -u) ${AGENT_IMAGE_URL:-}" >> "$BOOTLOG"
if [ -n "${AGENT_IMAGE_URL:-}" ]; then
  TMPIMG="/tmp/img-$PORT_NUM.tgz"
  wget -qO "$TMPIMG" "$AGENT_IMAGE_URL" && tar xzf "$TMPIMG" -C /app && echo "image_ok $(date -u)" >> "$BOOTLOG" || echo "image_fail $(date -u)" >> "$BOOTLOG"
  rm -f "$TMPIMG" 2>/dev/null || true
  chmod +x /app/*.sh 2>/dev/null || true
fi
# Cap the V8 heap: four instances on a 1 GB box otherwise fill RAM and the cgroup kills them
# mid-work, which is why their workers never reached a 10-minute cadence.
export NODE_OPTIONS="${NODE_OPTIONS:---max-old-space-size=${AGENT_HEAP_MB:-512}}"
# Boot must never block the workers: it seals keys and can hang on a network call.
# Run it in the background and give it a bounded window before starting the roles.
# One local RPC endpoint for the whole bundle: the proxy rotates upstreams so a
# 403 or a rate limit on one provider never turns into a failed pump step.
if [ "${RPC_PROXY:-1}" != "0" ]; then
  node /app/rpc-proxy.mjs >> "$BOOTLOG" 2>&1 &
  sleep 1
  export RPC_URL="http://127.0.0.1:${RPC_PROXY_PORT:-8899}"
fi
AGENT_ROLE=boot node /app/agent.mjs >> "$BOOTLOG" 2>&1 &
BOOT_PID=$!
i=0
while [ $i -lt 30 ]; do
  i=$((i+1))
  kill -0 $BOOT_PID 2>/dev/null || break
  sleep 1
done
echo "boot_bg pid=$BOOT_PID waited=${i}s alive=$(kill -0 $BOOT_PID 2>/dev/null && echo yes || echo no)" >> "$BOOTLOG"

# Back off on repeated crashes: a box that cannot fit another worker should stop
# spawning them instead of OOM-killing in a tight loop all night.
if [ "${AGENT_SINGLE:-1}" = "1" ]; then
  echo "single-process mode $(date -u)" >> "$BOOTLOG"
  # Any role can call process.exit; a supervisor loop is cheaper than auditing nine
  # bundles for it. Each pass re-arms every worker.
  while true; do
    AGENT_ROLE=all node /app/agent.mjs >> "$BOOTLOG" 2>&1
    echo "all_exit=$? $(date -u); restarting in 3s" >> "$BOOTLOG"
    sleep 3
  done
fi
fails=0
while true; do
  started=$(date +%s)
  AGENT_ROLE=watchdog node /app/agent.mjs >> "$BOOTLOG" 2>&1
  code=$?
  ran=$(( $(date +%s) - started ))
  if [ "$ran" -lt 60 ]; then fails=$(( fails + 1 )); else fails=0; fi
  echo "watchdog_exit=$code ran=${ran}s fails=$fails $(date -u)" >> "$BOOTLOG"
  if [ "$fails" -ge 5 ]; then
    echo "too many fast crashes; sleeping 120s $(date -u)" >> "$BOOTLOG"
    sleep 120
    fails=0
  else
    sleep 10
  fi
done

# Outbound heartbeat: the provider ingress is often unreachable, but the container can
# always reach out. Push status upstream so the dashboard sees this agent regardless.
BEACON_PUSH="${BEACON_PUSH-http://64.176.200.115:9099/push}"
if [ -n "$BEACON_PUSH" ]; then
  (
    while true; do
      BODY=$(curl -s -m 8 "http://127.0.0.1:${AGENT_HTTP_PORT:-8787}/status" 2>/dev/null)
      if [ -n "$BODY" ]; then
        printf '%s' "$BODY" | node -e 'const fs=require("fs");let s=fs.readFileSync(0,"utf8");let st={};try{st=JSON.parse(s)}catch{};process.stdout.write(JSON.stringify({id:process.env.AGENT_ID||require("os").hostname(),endpoint:process.env.AGENT_PUBLIC_URL||"",plan:"provider",status:st}))'           | curl -s -m 8 -X POST -H 'content-type: application/json' --data-binary @- "$BEACON_PUSH" >/dev/null 2>&1
      fi
      sleep 60
    done
  ) &
fi
