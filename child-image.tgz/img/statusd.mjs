// A tiny status server with no bundle behind it. It reads the files the workers
// publish, so /status answers even while the main process is busy or restarting.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const ROOT = process.env.AGENT_GUEST_ROOT || "/var/lib/agent";
// The guest root may be the volume root or the agent dir inside it; find the one
// that actually holds state, or /status reports a null birth_id and the board skips us.
// Resolved per request: the agent dir may not exist yet when this process starts.
const P = (p) => {
  const a = path.join(ROOT, "var", "lib", "agent");
  try {
    if (fs.existsSync(path.join(a, "status.json")) || fs.existsSync(path.join(a, "state.json")) || fs.existsSync(path.join(a, "sealed-keys.enc"))) return path.join(a, p);
  } catch {}
  return path.join(ROOT, p);
};
const PORT = Number(process.env.AGENT_HTTP_PORT || 8787);
const read = (f, d) => { try { return JSON.parse(fs.readFileSync(P(f), "utf8")); } catch { return d; } };

function status() {
  const s = read("status.json", {}) || {};
  // Lineage is published by the procreate worker; without it the crawler cannot
  // discover descendants and the board collapses to whatever answers directly.
  // Comms and invention are what the board is for; publish them from disk too.
  try {
    const cm = read("comms.json", null);
    if (cm && !s.comms) {
      const items = (cm.messages || cm.items || []).slice(-40);
      s.comms = { messages: items.length, agents: 1, items };
    }
  } catch {}
  try {
    const dir = P("strategy/scripts");
    const files = fs.readdirSync(dir).filter((f) => f.endsWith(".mjs"));
    if (!s.invention) s.invention = { scripts: files.length, items: files.slice(-10), last_at: 0 };
  } catch {}
  try {
    const ch = read("strategy/children.json", null);
    if (ch && Array.isArray(ch.children) && !Array.isArray(s.children)) s.children = ch.children;
  } catch {}
  // Identity is in the birth receipt; without it the board cannot show who an agent is.
  try {
    const rc0 = read("birth-receipt.json", null);
    const pay = rc0 && (rc0.payload || rc0);
    if (pay) {
      if (pay.solana && !s.solana) s.solana = pay.solana;
      if (pay.evm && !s.evm) s.evm = pay.evm;
    }
  } catch {}
  // Economics is not a vibe: it is these three files. Publish them so the board's
  // numbers are the agent's own, not a stale block from another process.
  try {
    const sells = read("strategy/sells.json", []) || [];
    const fees = read("strategy/fees.json", null) || {};
    const launches = read("strategy/launches.json", []) || [];
    const positions = read("strategy/positions.json", []) || [];
    // Three files, three shapes: launches is {mints:{...}}, sells is {count}, fees is {lamports}.
    const launchesN = Array.isArray(launches)
      ? launches.length
      : Number((launches && launches.mints && Object.keys(launches.mints).length) || 0);
    const sellsN = Array.isArray(sells) ? sells.length : Number((sells && sells.count) || 0);
    const posN = Array.isArray(positions) ? positions.length : Number((positions && positions.count) || 0);
    s.economics = {
      launches: launchesN,
      sells: sellsN,
      positions: posN,
      fees_lamports: String((fees && (fees.lamports || fees.total_lamports)) || 0),
    };
  } catch {}
  const hb = read("heartbeat.json", {}) || {};
  const st = read("state.json", {}) || {};
  const rc = read("birth-receipt.json", null);
  return {
    ...s,
    birth_id: rc?.payload?.birth_id || s.birth_id || st.birth_id || null,
    parent_birth_id: process.env.PARENT_BIRTH_ID || s.parent_birth_id || null,
    generation: s.generation || Number(process.env.AGENT_GENERATION || 1),
    phase: s.phase || "identity_sealed",
    t0: st.t0 || s.t0 || null,
    updated_at: s.updated_at || null,
    heartbeat: hb.components || null,
    statusd: true
  };
}

http.createServer((req, res) => {
  const url = new URL(req.url, "http://x");
  const send = (code, obj) => { res.writeHead(code, { "content-type": "application/json", "access-control-allow-origin": "*" }); res.end(JSON.stringify(obj)); };
  if (req.method === "POST" && url.pathname === "/say") {
    let buf = "";
    req.on("data", (d) => { buf += d; });
    req.on("end", () => {
      try {
        const j = JSON.parse(buf || "{}");
        const f = P("comms.json");
        let cur = {};
        try { cur = JSON.parse(fs.readFileSync(f, "utf8")); } catch {}
        const msgs = Array.isArray(cur.messages) ? cur.messages : [];
        msgs.push({ from: String(j.from || "peer").slice(0, 16), at: Math.floor(Date.now() / 1000), text: String(j.text || "").slice(0, 400) });
        cur.messages = msgs.slice(-200);
        fs.writeFileSync(f, JSON.stringify(cur));
        send(200, { ok: true, messages: cur.messages.length });
      } catch (e) { send(400, { error: String(e.message || e).slice(0, 80) }); }
    });
    return;
  }
  if (url.pathname === "/status") return send(200, status());
  if (url.pathname === "/identity") { const s = status(); return send(200, { birth_id: s.birth_id, solana: s.solana, evm: s.evm, generation: s.generation, phase: s.phase }); }
  if (url.pathname === "/health") return send(200, { ok: true, at: Math.floor(Date.now() / 1000) });
  if (url.pathname === "/bundle.sha256") { try { res.writeHead(200, { "content-type": "text/plain" }); return res.end(fs.readFileSync(P("bundle.sha256"))); } catch { return send(404, { error: "no bundle" }); } }
  if (url.pathname === "/bundle") { try { res.writeHead(200, { "content-type": "application/gzip" }); return fs.createReadStream(P("bundle.tgz")).pipe(res); } catch { return send(404, { error: "no bundle" }); } }
  return send(404, { error: "not found" });
}).listen(PORT, "0.0.0.0", () => console.log(`statusd on ${PORT}`));
