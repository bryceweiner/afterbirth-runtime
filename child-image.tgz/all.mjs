// One process, every worker: the 2 GB boxes die when ten node processes fight over a
// single heap. Each module below starts its own timers, so importing them in order is
// the whole supervisor.
import fs from 'node:fs';
import { spawn } from 'node:child_process';
const LOG = '/var/lib/agent/all.log';
const log=(m)=>{try{fs.appendFileSync('/var/lib/agent/all.log',new Date().toISOString()+' '+m+'\n')}catch{}};
process.on('uncaughtException',(e)=>log('uncaught '+(e&&e.message)));
process.on('unhandledRejection',(e)=>log('reject '+String(e&&e.message||e)));
// resilience supervises and calls process.exit(1) on a failed probe; it gets its own
// process so it cannot take identity and the workers down with it.
const SUPERVISED = new Set(['resilience']);
const roles = (process.env.AGENT_ALL_ROLES || 'signer,identity-server,loops,strategy,earn,procreate,brain,distributor,resilience').split(',').map((s) => s.trim()).filter(Boolean);
// Role names are not file names: earn lives in strategy-earn.mjs, procreate in
// strategy-procreate.mjs. Importing `${role}.mjs` silently loaded nothing.
const FILE = { 'earn': 'strategy-earn', 'strategy': 'strategy-worker', 'procreate': 'strategy-procreate', 'distribution': 'distributor' };
for (const r of roles.filter((x) => SUPERVISED.has(x))) {
  const child = spawn(process.execPath, [process.argv[1]], { env: { ...process.env, AGENT_ROLE: r }, stdio: ['ignore', fs.openSync(LOG, 'a'), fs.openSync(LOG, 'a')] });
  child.on('exit', (code) => log('supervised ' + r + ' exit ' + code));
  log('supervised ' + r + ' pid ' + child.pid);
}
// The signer must be listening before anything tries to sign: the workers read its
// port file at import time and a race here is what produced ECONNREFUSED in loops.
if (roles.includes('signer')) {
  await import('./signer.mjs').catch((e) => log('ERR signer ' + (e && e.message)));
  await new Promise((r) => setTimeout(r, 2500));
  log('signer up');
}
for (const r of roles.filter((x) => !SUPERVISED.has(x) && x !== 'signer')) {
  // Fire them together: identity-server keeps the event loop busy, so awaiting each
  // serially means the workers never load at all. Every module arms its own timers.
  const f = FILE[r] || r;
  log('load ' + r + ' -> ' + f);
  import(`./${f}.mjs`).then(()=>log('ok '+r)).catch((e)=>log('ERR '+r+' '+String((e&&e.message)||e).slice(0,200)));
}

// Nothing here is allowed to exit: the roles arm their own timers, but a pending
// dynamic import alone does not hold the event loop, so the process used to die
// silently right after loading them.
setInterval(() => log('keep-alive'), 60000);
log('all armed');
